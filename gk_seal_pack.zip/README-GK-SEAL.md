# GK Seal

Embed the Guru Codex Seal v1.0 across the repo.

## Use
- Commit `tools/gk_seal_check.py`
- Add workflow `.github/workflows/gk-seal.yml`
- Push. On failures, a PR will be created to add headers.

Integrity tag: **GKCI-2025-7F3A2E**  
Oath: *Through every line, leave the world lighter than before.*
